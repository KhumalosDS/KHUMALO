
import { useState } from "react";
import { addMinutes, parse, format } from "date-fns";

export const lessonTypes = [
  { id: "learners", label: "Learner's Lesson", duration: 60 },
  { id: "beginner", label: "Beginner Driver", duration: 20 },
  { id: "intermediate", label: "Intermediate Driver", duration: 35 },
  { id: "advanced", label: "Advanced Driver", duration: 60 }
];

export const operatingHours = {
  start: "08:00",
  end: "17:00"
};

export const useLessonData = () => {
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [timeSlot, setTimeSlot] = useState<string | undefined>(undefined);
  const [lessonType, setLessonType] = useState<string | undefined>(undefined);
  const [availableTimeSlots, setAvailableTimeSlots] = useState<string[]>([]);

  const generateTimeSlots = (selectedDate: Date | undefined, selectedLessonType: string | undefined) => {
    if (!selectedDate || !selectedLessonType) return [];

    const slots: string[] = [];
    const selectedLesson = lessonTypes.find(lt => lt.id === selectedLessonType);
    if (!selectedLesson) return [];

    const duration = selectedLesson.duration;
    let currentTime = parse(operatingHours.start, "HH:mm", selectedDate);
    const endTime = parse(operatingHours.end, "HH:mm", selectedDate);

    while (currentTime < endTime) {
      slots.push(format(currentTime, "HH:mm"));
      currentTime = addMinutes(currentTime, duration);
    }

    return slots;
  };

  const handleLessonTypeChange = (type: string) => {
    setLessonType(type);
    const slots = generateTimeSlots(date, type);
    setAvailableTimeSlots(slots);
    setTimeSlot(undefined);
  };

  const handleDateChange = (newDate: Date | undefined) => {
    setDate(newDate);
    const slots = generateTimeSlots(newDate, lessonType);
    setAvailableTimeSlots(slots);
    setTimeSlot(undefined);
  };

  return {
    lessonTypes,
    date,
    setDate,
    timeSlot,
    setTimeSlot,
    lessonType,
    setLessonType,
    availableTimeSlots,
    setAvailableTimeSlots,
    handleLessonTypeChange,
    handleDateChange,
  };
};
