
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const useBookingData = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: instructors, isLoading: loadingInstructors } = useQuery({
    queryKey: ["instructors"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, full_name")
        .eq("user_type", "instructor");

      if (error) {
        console.error("Error fetching instructors:", error);
        throw error;
      }
      
      if (!data || data.length === 0) {
        const { data: newInstructor, error: createError } = await supabase
          .from("profiles")
          .insert({
            id: "00000000-0000-0000-0000-000000000001",
            full_name: "Demo Instructor",
            user_type: "instructor",
            sa_id_number: "0000000000000"
          })
          .select();
          
        if (createError) {
          console.error("Error creating demo instructor:", createError);
          return [];
        }
        
        return newInstructor;
      }
      
      return data;
    },
  });

  const { data: session, isLoading: loadingSession } = useQuery({
    queryKey: ["session"],
    queryFn: async () => {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) throw error;
      return session;
    },
  });

  const { data: userProfile, isLoading: loadingProfile } = useQuery({
    queryKey: ["userProfile", session?.user?.id],
    enabled: !!session?.user?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", session!.user.id)
        .maybeSingle();
        
      if (error) throw error;
      return data;
    },
  });

  return {
    instructors,
    session,
    userProfile,
    isSubmitting,
    setIsSubmitting,
    loading: loadingInstructors || loadingSession || loadingProfile
  };
};
