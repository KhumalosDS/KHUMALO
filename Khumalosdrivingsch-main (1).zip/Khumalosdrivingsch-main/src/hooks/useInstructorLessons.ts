
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface Lesson {
  id: string;
  student_id: string;
  student_name?: string;
  lesson_type: string;
  lesson_date: string;
  status: "pending" | "attended" | "missed";
  duration: number;
}

interface Stats {
  totalLessons: number;
  completedLessons: number;
  pendingLessons: number;
  cancelledLessons: number;
  totalHours: number;
}

export const useInstructorLessons = () => {
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalLessons: 0,
    completedLessons: 0,
    pendingLessons: 0,
    cancelledLessons: 0,
    totalHours: 0
  });
  const { toast } = useToast();

  const fetchLessons = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('lessons')
        .select(`
          id,
          student_id,
          lesson_type,
          lesson_date,
          status,
          duration
        `)
        .eq('instructor_id', user.id)
        .order('lesson_date', { ascending: true });

      if (error) throw error;

      // Get student names
      const lessonsWithNames = await Promise.all((data || []).map(async (lesson) => {
        const { data: studentData } = await supabase
          .from('profiles')
          .select('full_name')
          .eq('id', lesson.student_id)
          .maybeSingle();
        
        return {
          ...lesson,
          student_name: studentData?.full_name || 'Unknown Student'
        };
      }));
      
      setLessons(lessonsWithNames);
      
      // Calculate stats
      const totalLessons = lessonsWithNames.length;
      const completedLessons = lessonsWithNames.filter(l => l.status === 'attended').length;
      const pendingLessons = lessonsWithNames.filter(l => l.status === 'pending').length;
      const cancelledLessons = lessonsWithNames.filter(l => l.status === 'missed').length;
      const totalHours = lessonsWithNames.reduce((acc, lesson) => {
        if (lesson.status === 'attended') {
          return acc + (lesson.duration / 60);
        }
        return acc;
      }, 0);
      
      setStats({
        totalLessons,
        completedLessons,
        pendingLessons,
        cancelledLessons,
        totalHours
      });
      
      // Update the instructor's statistics in their profile
      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          lessons_stats: {
            total: totalLessons,
            completed: completedLessons,
            pending: pendingLessons,
            cancelled: cancelledLessons,
            hours: totalHours
          }
        })
        .eq('id', user.id);
        
      if (updateError) {
        console.error("Error updating instructor stats:", updateError);
      }
      
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const updateLessonStatus = async (lessonId: string, status: "attended" | "missed") => {
    try {
      const { error } = await supabase
        .from('lessons')
        .update({ status })
        .eq('id', lessonId);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Lesson marked as ${status}`,
      });

      fetchLessons();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchLessons();
  }, []);

  return {
    lessons,
    stats,
    updateLessonStatus,
    fetchLessons
  };
};
