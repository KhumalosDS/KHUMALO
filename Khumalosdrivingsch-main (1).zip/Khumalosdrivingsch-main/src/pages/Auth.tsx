
import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LoginForm } from "@/components/auth/LoginForm";
import { SignUpForm } from "@/components/auth/SignUpForm";
import { PasswordResetForm } from "@/components/auth/PasswordResetForm";

const Auth = () => {
  const [authMode, setAuthMode] = useState<"login" | "signup" | "reset">("login");

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8 px-4 md:py-16">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>
              {authMode === "login" 
                ? "Login" 
                : authMode === "signup" 
                  ? "Sign Up" 
                  : "Reset Password"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {authMode === "login" ? (
              <LoginForm />
            ) : authMode === "signup" ? (
              <SignUpForm onSuccess={() => setAuthMode("login")} />
            ) : (
              <PasswordResetForm onSuccess={() => setAuthMode("login")} />
            )}
            
            <div className="space-y-2 mt-4">
              {authMode === "login" && (
                <>
                  <Button
                    type="button"
                    variant="ghost"
                    className="w-full"
                    onClick={() => setAuthMode("signup")}
                  >
                    Need an account? Sign Up
                  </Button>
                  <Button
                    type="button"
                    variant="link"
                    className="w-full"
                    onClick={() => setAuthMode("reset")}
                  >
                    Forgot password?
                  </Button>
                </>
              )}
              {authMode === "signup" && (
                <Button
                  type="button"
                  variant="ghost"
                  className="w-full"
                  onClick={() => setAuthMode("login")}
                >
                  Already have an account? Login
                </Button>
              )}
              {authMode === "reset" && (
                <Button
                  type="button"
                  variant="ghost"
                  className="w-full"
                  onClick={() => setAuthMode("login")}
                >
                  Back to Login
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Auth;
