
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Hero } from "@/components/Hero";
import { Services } from "@/components/Services";
import { Testimonials } from "@/components/Testimonials";

const Index = () => {
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      
      <div className="container mx-auto py-12 px-4">
        <div className="mt-12 grid md:grid-cols-3 gap-8">
          <div className="bg-card rounded-lg p-6 shadow-sm">
            <h3 className="text-xl font-bold mb-3">Professional Instructors</h3>
            <p className="text-muted-foreground">
              Our experienced instructors are certified and dedicated to your success.
            </p>
          </div>
          <div className="bg-card rounded-lg p-6 shadow-sm">
            <h3 className="text-xl font-bold mb-3">Comprehensive Lessons</h3>
            <p className="text-muted-foreground">
              From beginners to proficient drivers, we have courses for every skill level.
            </p>
          </div>
          <div className="bg-card rounded-lg p-6 shadow-sm">
            <h3 className="text-xl font-bold mb-3">Test Preparation</h3>
            <p className="text-muted-foreground">
              We'll help you prepare for and pass your driving test with confidence.
            </p>
          </div>
        </div>
      </div>
      
    </div>
  );
};

export default Index;
