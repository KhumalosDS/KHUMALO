
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StudentLessonTracker } from "@/components/student/StudentLessonTracker";
import { TestingReadyBanner } from "@/components/student/TestingReadyBanner";
import { ProductivityChart } from "@/components/instructor/ProductivityChart";
import { Loader2 } from "lucide-react";

// Define the structure for lesson stats
type LessonStats = {
  total?: number;
  completed?: number;
  pending?: number;
  cancelled?: number;
  hours?: number;
};

// Define the structure for profile data
type ProfileData = {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  user_type: "student" | "instructor" | "admin";
  sa_id_number: string;
  testing_ready: boolean;
  lessons_stats: LessonStats;
  created_at: string;
  updated_at: string;
};

const Profile = () => {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProfile = async () => {
      setLoading(true);
      
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        navigate("/auth");
        return;
      }
      
      // Fetch user profile
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", session.user.id)
        .single();
        
      if (error) {
        toast({
          title: "Error",
          description: "Failed to load profile",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }
      
      // Convert JSON lessons_stats to expected type or use default
      const processedData = {
        ...data,
        lessons_stats: data.lessons_stats ? 
          (typeof data.lessons_stats === 'string' ? 
            JSON.parse(data.lessons_stats) : data.lessons_stats) as LessonStats
          : { total: 0, completed: 0, pending: 0, cancelled: 0, hours: 0 }
      };
      
      setProfile(processedData);
      setLoading(false);
    };
    
    fetchProfile();
  }, [navigate, toast]);

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8 px-4">
        {profile && (
          <>
            {profile.user_type === "student" && profile.testing_ready && (
              <TestingReadyBanner isReadyForTesting={profile.testing_ready} />
            )}
            
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>User Profile</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-xl font-semibold">{profile.full_name}</h3>
                    <p className="text-muted-foreground">{profile.email}</p>
                  </div>
                  
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <p className="font-medium">Phone Number</p>
                      <p className="text-muted-foreground">{profile.phone || "Not provided"}</p>
                    </div>
                    <div>
                      <p className="font-medium">SA ID Number</p>
                      <p className="text-muted-foreground">{profile.sa_id_number}</p>
                    </div>
                    <div>
                      <p className="font-medium">User Type</p>
                      <p className="text-muted-foreground capitalize">{profile.user_type}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {profile.user_type === "student" && (
              <StudentLessonTracker studentId={profile.id} />
            )}
            
            {profile.user_type === "instructor" && (
              <div className="grid gap-6 md:grid-cols-2">
                <ProductivityChart stats={{
                  completedLessons: profile.lessons_stats?.completed || 0,
                  pendingLessons: profile.lessons_stats?.pending || 0,
                  cancelledLessons: profile.lessons_stats?.cancelled || 0
                }} />
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Profile;
