import { Navbar } from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

const pricingData = [
  {
    code: "Code B",
    price: "R2000",
    deposit: "R850",
    description: "Light motor vehicles up to 3500kg",
  },
  {
    code: "Code C1",
    price: "R1500",
    deposit: "R500",
    description: "Heavy motor vehicles between 3500kg and 16000kg",
  },
  {
    code: "Code EC",
    price: "R3500",
    deposit: "R1000",
    description: "Extra heavy motor vehicles over 16000kg",
  },
];

const Pricing = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen">
      <Navbar />
      <div className="container py-16">
        <h1 className="text-4xl font-bold text-primary mb-12 text-center">License Pricing</h1>
        <div className="grid md:grid-cols-3 gap-8">
          {pricingData.map((item) => (
            <Card key={item.code} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-2xl">{item.code}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">{item.description}</p>
                <div className="space-y-2">
                  <p className="text-2xl font-bold text-primary">{item.price}</p>
                  <p className="text-sm text-gray-500">Deposit: {item.deposit}</p>
                  <Button 
                    className="w-full mt-4"
                    onClick={() => navigate("/booking")}
                  >
                    Book Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Pricing;