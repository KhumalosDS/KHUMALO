
import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";
import { AdminDashboardTabs } from "@/components/admin/AdminDashboardTabs";

const AdminDashboard = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [profiles, setProfiles] = useState<any[]>([]);
  const [lessons, setLessons] = useState<any[]>([]);
  const [instructors, setInstructors] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);

  const loadData = useCallback(async () => {
    console.log("Loading admin dashboard data...");
    setLoading(true);
    
    try {
      // Fetch all user profiles
      const { data: profilesData, error: profilesError } = await supabase
        .from("profiles")
        .select("*");
        
      if (profilesError) {
        console.error("Error loading profiles:", profilesError);
        toast({
          title: "Error",
          description: "Failed to load user profiles",
          variant: "destructive",
        });
        return;
      }
      
      console.log("Profiles loaded:", profilesData?.length || 0);
      setProfiles(profilesData || []);
      
      // Filter instructors and students
      setInstructors(profilesData?.filter(p => p.user_type === "instructor") || []);
      setStudents(profilesData?.filter(p => p.user_type === "student") || []);
      
      // Fetch all lessons
      const { data: lessonsData, error: lessonsError } = await supabase
        .from("lessons")
        .select("*");
        
      if (lessonsError) {
        console.error("Error loading lessons:", lessonsError);
        toast({
          title: "Error",
          description: "Failed to load lessons",
          variant: "destructive",
        });
        return;
      }
      
      // Enhance lessons with instructor and student names
      console.log("Raw lessons loaded:", lessonsData?.length || 0);
      
      const enhancedLessons = await Promise.all((lessonsData || []).map(async (lesson) => {
        try {
          const { data: studentData } = await supabase
            .from("profiles")
            .select("full_name")
            .eq("id", lesson.student_id)
            .single();
            
          const { data: instructorData } = await supabase
            .from("profiles")
            .select("full_name")
            .eq("id", lesson.instructor_id)
            .single();
            
          return {
            ...lesson,
            student_name: studentData?.full_name || "Unknown",
            instructor_name: instructorData?.full_name || "Unknown",
          };
        } catch (err) {
          console.error("Error enhancing lesson:", err);
          return {
            ...lesson,
            student_name: "Unknown",
            instructor_name: "Unknown",
          };
        }
      }));
      
      console.log("Enhanced lessons:", enhancedLessons?.length || 0);
      setLessons(enhancedLessons || []);
    } catch (error) {
      console.error("Error in loadData:", error);
      toast({
        title: "Error",
        description: "An unexpected error occurred while loading data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    const checkAdmin = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (!session) {
          navigate("/auth");
          return;
        }
        
        const { data, error } = await supabase
          .from("profiles")
          .select("user_type")
          .eq("id", session.user.id)
          .single();
          
        if (error || data.user_type !== "admin") {
          toast({
            title: "Access Denied",
            description: "You must be an administrator to view this page",
            variant: "destructive",
          });
          navigate("/");
          return;
        }
        
        setIsAdmin(true);
        await loadData();
      } catch (error) {
        console.error("Error checking admin status:", error);
        toast({
          title: "Error",
          description: "An unexpected error occurred",
          variant: "destructive",
        });
        navigate("/");
      }
    };
    
    checkAdmin();
  }, [navigate, toast, loadData]);

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }
  
  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-6">Administrator Dashboard</h1>
        
        <AdminDashboardTabs
          profiles={profiles}
          lessons={lessons}
          instructors={instructors}
          students={students}
          isLoading={loading}
          onDataRefresh={loadData}
        />
      </div>
    </div>
  );
};

export default AdminDashboard;
