
import { Navbar } from "@/components/Navbar";
import { useInstructorLessons } from "@/hooks/useInstructorLessons";
import { InstructorDashboardContent } from "@/components/instructor/InstructorDashboardContent";

const InstructorDashboard = () => {
  const { lessons, stats, updateLessonStatus } = useInstructorLessons();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8 px-4 md:py-16">
        <h1 className="text-3xl font-bold mb-8">Instructor Dashboard</h1>
        
        <InstructorDashboardContent 
          stats={stats} 
          lessons={lessons} 
          onUpdateStatus={updateLessonStatus}
        />
      </div>
    </div>
  );
};

export default InstructorDashboard;
