import { createClient } from '@supabase/supabase-js';

const supabaseUrl = "https://tvahyrzqlovrfauqlxmh.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR2YWh5cnpxbG92cmZhdXFseG1oIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzgxNjA5NzQsImV4cCI6MjA1MzczNjk3NH0.CfrbKfs02d7F0bjCXevadxxd2sKOeDJwaOQmOBj7FbA";

if (!supabaseUrl) {
  console.error('Missing VITE_SUPABASE_URL environment variable');
}

if (!supabaseAnonKey) {
  console.error('Missing VITE_SUPABASE_ANON_KEY environment variable');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);