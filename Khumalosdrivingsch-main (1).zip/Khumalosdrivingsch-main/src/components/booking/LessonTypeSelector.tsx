
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

interface LessonType {
  id: string;
  label: string;
  duration: number;
}

interface LessonTypeSelectorProps {
  lessonTypes: LessonType[];
  selectedType: string | undefined;
  onTypeSelect: (type: string) => void;
}

export const LessonTypeSelector = ({
  lessonTypes,
  selectedType,
  onTypeSelect,
}: LessonTypeSelectorProps) => {
  return (
    <div>
      <h3 className="text-lg font-medium mb-3">Lesson Type</h3>
      <RadioGroup onValueChange={onTypeSelect} value={selectedType} className="space-y-2">
        {lessonTypes.map((type) => (
          <div key={type.id} className="flex items-center space-x-2 rounded-lg border p-4">
            <RadioGroupItem value={type.id} id={type.id} />
            <label
              htmlFor={type.id}
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex-1"
            >
              {type.label} ({type.duration} minutes)
            </label>
          </div>
        ))}
      </RadioGroup>
    </div>
  );
};
