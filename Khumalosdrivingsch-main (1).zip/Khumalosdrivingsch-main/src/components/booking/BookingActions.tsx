
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

interface BookingActionsProps {
  onBookingSubmit: () => Promise<void>;
  isSubmitting: boolean;
}

export const BookingActions = ({ onBookingSubmit, isSubmitting }: BookingActionsProps) => {
  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle>Confirm Your Booking</CardTitle>
      </CardHeader>
      <CardContent>
        <Button 
          onClick={onBookingSubmit} 
          disabled={isSubmitting} 
          className="w-full"
          size="lg"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : "Book Lesson"}
        </Button>
        <p className="text-sm text-gray-500 mt-2">
          By booking a lesson, you agree to our terms and conditions.
        </p>
      </CardContent>
    </Card>
  );
};
