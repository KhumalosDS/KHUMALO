
import { Calendar } from "@/components/ui/calendar";

interface BookingCalendarProps {
  date: Date | undefined;
  onDateSelect: (date: Date | undefined) => void;
}

export const BookingCalendar = ({ date, onDateSelect }: BookingCalendarProps) => {
  return (
    <Calendar
      mode="single"
      selected={date}
      onSelect={onDateSelect}
      className="rounded-md border"
      disabled={(date) => date < new Date() || date.getDay() === 0}
    />
  );
};
