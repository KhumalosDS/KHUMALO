
import { format } from "date-fns";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle2 } from "lucide-react";

interface BookingSummaryProps {
  date?: Date;
  timeSlot?: string;
  lessonType?: string;
  lessonTypes: Array<{
    id: string;
    label: string;
    duration: number;
  }>;
}

export const BookingSummary = ({
  date,
  timeSlot,
  lessonType,
  lessonTypes,
}: BookingSummaryProps) => {
  if (!date && !timeSlot && !lessonType) return null;

  return (
    <Card className="mb-8 bg-accent/10">
      <CardHeader>
        <CardTitle className="text-xl">Selected Booking Details</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {date && (
          <Alert>
            <CheckCircle2 className="h-4 w-4" />
            <AlertDescription>
              Date: {format(date, "EEEE, MMMM do, yyyy")}
            </AlertDescription>
          </Alert>
        )}
        {timeSlot && (
          <Alert>
            <CheckCircle2 className="h-4 w-4" />
            <AlertDescription>Time: {timeSlot}</AlertDescription>
          </Alert>
        )}
        {lessonType && (
          <Alert>
            <CheckCircle2 className="h-4 w-4" />
            <AlertDescription>
              Lesson: {lessonTypes.find((lt) => lt.id === lessonType)?.label}
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
};
