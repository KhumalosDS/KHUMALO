
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { BookingCalendar } from "./BookingCalendar";
import { LessonTypeSelector } from "./LessonTypeSelector";
import { TimeSlotPicker } from "./TimeSlotPicker";

interface BookingFormProps {
  date: Date | undefined;
  lessonType: string | undefined;
  timeSlot: string | undefined;
  availableTimeSlots: string[];
  onDateSelect: (date: Date | undefined) => void;
  onLessonTypeSelect: (type: string) => void;
  onTimeSlotSelect: (timeSlot: string) => void;
  onBookingSubmit: () => void;
  isSubmitting: boolean;
}

export const BookingForm = ({
  date,
  lessonType,
  timeSlot,
  availableTimeSlots,
  onDateSelect,
  onLessonTypeSelect,
  onTimeSlotSelect,
  onBookingSubmit,
  isSubmitting
}: BookingFormProps) => {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Select a Date</CardTitle>
        </CardHeader>
        <CardContent>
          <BookingCalendar date={date} onDateSelect={onDateSelect} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Select Time & Duration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <LessonTypeSelector
            lessonTypes={[
              { id: "learners", label: "Learner's Lesson", duration: 60 },
              { id: "beginner", label: "Beginner Driver", duration: 20 },
              { id: "intermediate", label: "Intermediate Driver", duration: 35 },
              { id: "advanced", label: "Advanced Driver", duration: 60 }
            ]}
            selectedType={lessonType}
            onTypeSelect={onLessonTypeSelect}
          />

          {lessonType && (
            <TimeSlotPicker
              availableTimeSlots={availableTimeSlots}
              selectedTimeSlot={timeSlot}
              onTimeSlotSelect={onTimeSlotSelect}
            />
          )}

          <Button 
            onClick={onBookingSubmit}
            className="w-full"
            size="lg"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Booking...
              </>
            ) : (
              "Book Lesson"
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};
