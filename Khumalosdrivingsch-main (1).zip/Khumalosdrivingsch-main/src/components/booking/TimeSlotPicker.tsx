
import { Button } from "@/components/ui/button";

interface TimeSlotPickerProps {
  availableTimeSlots: string[];
  selectedTimeSlot: string | undefined;
  onTimeSlotSelect: (slot: string) => void;
}

export const TimeSlotPicker = ({
  availableTimeSlots,
  selectedTimeSlot,
  onTimeSlotSelect,
}: TimeSlotPickerProps) => {
  if (!availableTimeSlots.length) return null;

  return (
    <div>
      <h3 className="text-lg font-medium mb-3">Available Time Slots</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {availableTimeSlots.map((slot) => (
          <Button
            key={slot}
            variant={selectedTimeSlot === slot ? "default" : "outline"}
            onClick={() => onTimeSlotSelect(slot)}
            className="w-full"
          >
            {slot}
          </Button>
        ))}
      </div>
    </div>
  );
};
