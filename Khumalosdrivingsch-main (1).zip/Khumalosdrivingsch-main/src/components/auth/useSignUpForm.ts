
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { validatePassword, validateSaId, validatePhoneNumber } from "./validation";

export const useSignUpForm = (onSuccess: () => void) => {
  const [userType, setUserType] = useState<"student" | "instructor" | "admin">("student");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [saIdNumber, setSaIdNumber] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [adminCode, setAdminCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showAdminField, setShowAdminField] = useState(false);
  const { toast } = useToast();

  const validateForm = async () => {
    if (userType === "admin" && adminCode !== "admin123") {
      toast({
        title: "Invalid Admin Code",
        description: "The admin code you entered is incorrect",
        variant: "destructive",
      });
      return false;
    }
    
    if (!validateSaId(saIdNumber)) {
      toast({
        title: "Invalid ID Number",
        description: "Please enter a valid 13-digit South African ID number",
        variant: "destructive",
      });
      return false;
    }

    if (!validatePassword(password)) {
      toast({
        title: "Invalid Password",
        description: "Password must be at least 6 characters and contain at least 1 number",
        variant: "destructive",
      });
      return false;
    }

    if (!validatePhoneNumber(phoneNumber)) {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid South African phone number",
        variant: "destructive",
      });
      return false;
    }

    // Check if SA ID number is already in use
    const { data: existingUsers, error: checkError } = await supabase
      .from("profiles")
      .select("id")
      .eq("sa_id_number", saIdNumber);
    
    if (checkError) {
      console.error("Error checking ID number:", checkError);
      toast({
        title: "Error",
        description: "Could not verify ID number uniqueness",
        variant: "destructive",
      });
      return false;
    }
    
    if (existingUsers && existingUsers.length > 0) {
      toast({
        title: "ID Number Already Registered",
        description: "An account with this ID number already exists",
        variant: "destructive",
      });
      return false;
    }

    // Check if email is already in use
    const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password: "dummy-password-for-check",
    });
    
    if (authData?.user) {
      toast({
        title: "Email Already Registered",
        description: "An account with this email already exists",
        variant: "destructive",
      });
      return false;
    }

    return true;
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      if (!(await validateForm())) {
        setIsLoading(false);
        return;
      }

      console.log("Attempting signup with user type:", userType);

      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: name,
            sa_id_number: saIdNumber,
            user_type: userType,
            phone: phoneNumber,
            email: email
          }
        }
      });

      if (authError) {
        console.error("Auth error:", authError);
        throw authError;
      }

      if (!authData.user) {
        throw new Error("User creation failed");
      }

      toast({
        title: "Success",
        description: "Account created successfully. Please check your email for verification.",
      });
      
      onSuccess();
    } catch (error: any) {
      console.error("Signup error:", error);
      toast({
        title: "Error",
        description: error.message || "An error occurred during signup",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return {
    userType,
    setUserType,
    email,
    setEmail,
    password,
    setPassword,
    name,
    setName,
    saIdNumber,
    setSaIdNumber,
    phoneNumber,
    setPhoneNumber,
    adminCode,
    setAdminCode,
    isLoading,
    showAdminField,
    setShowAdminField,
    handleSignUp
  };
};
