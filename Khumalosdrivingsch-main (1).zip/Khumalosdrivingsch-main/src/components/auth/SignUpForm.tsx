
import { Button } from "@/components/ui/button";
import { FormField } from "./FormField";
import { UserTypeSelector } from "./UserTypeSelector";
import { AdminCodeField } from "./AdminCodeField";
import { useSignUpForm } from "./useSignUpForm";

interface SignUpFormProps {
  onSuccess: () => void;
}

export const SignUpForm = ({ onSuccess }: SignUpFormProps) => {
  const {
    userType,
    setUserType,
    email,
    setEmail,
    password,
    setPassword,
    name,
    setName,
    saIdNumber,
    setSaIdNumber,
    phoneNumber,
    setPhoneNumber,
    adminCode,
    setAdminCode,
    isLoading,
    showAdminField,
    setShowAdminField,
    handleSignUp
  } = useSignUpForm(onSuccess);

  return (
    <div className="space-y-6">
      <form onSubmit={handleSignUp} className="space-y-4">
        <FormField
          id="name"
          label="Full Name"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />

        <UserTypeSelector 
          userType={userType}
          onUserTypeChange={setUserType}
          setShowAdminField={setShowAdminField}
        />

        {showAdminField && (
          <AdminCodeField
            adminCode={adminCode}
            onChange={(e) => setAdminCode(e.target.value)}
            required={userType === "admin"}
          />
        )}

        <FormField
          id="email"
          label="Email Address"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <FormField
          id="phoneNumber"
          label="Phone Number"
          type="tel"
          value={phoneNumber}
          onChange={(e) => setPhoneNumber(e.target.value)}
          required
        />

        <FormField
          id="saIdNumber"
          label="South African ID Number"
          type="text"
          value={saIdNumber}
          onChange={(e) => setSaIdNumber(e.target.value)}
          required
          maxLength={13}
          pattern="\d{13}"
          title="Please enter a valid 13-digit South African ID number"
        />

        <FormField
          id="password"
          label="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          minLength={6}
          title="Password must be at least 6 characters and contain at least 1 number"
        />

        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading ? "Creating Account..." : "Sign Up with Email"}
        </Button>
      </form>
    </div>
  );
};
