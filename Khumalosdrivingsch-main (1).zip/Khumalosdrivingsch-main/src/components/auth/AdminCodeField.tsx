
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface AdminCodeFieldProps {
  adminCode: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  required: boolean;
}

export const AdminCodeField = ({ adminCode, onChange, required }: AdminCodeFieldProps) => {
  return (
    <div className="space-y-2">
      <Label htmlFor="adminCode">Admin Code</Label>
      <Input
        id="adminCode"
        type="password"
        value={adminCode}
        onChange={onChange}
        placeholder="Enter admin code"
        required={required}
      />
    </div>
  );
};
