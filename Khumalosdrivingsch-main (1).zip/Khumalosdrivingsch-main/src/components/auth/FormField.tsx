
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface FormFieldProps {
  id: string;
  label: string;
  type: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  required?: boolean;
  maxLength?: number;
  pattern?: string;
  title?: string;
  minLength?: number;
}

export const FormField = ({
  id,
  label,
  type,
  value,
  onChange,
  required = false,
  maxLength,
  pattern,
  title,
  minLength,
}: FormFieldProps) => {
  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label}</Label>
      <Input
        id={id}
        type={type}
        value={value}
        onChange={onChange}
        required={required}
        maxLength={maxLength}
        pattern={pattern}
        title={title}
        minLength={minLength}
      />
    </div>
  );
};
