
export const validatePassword = (password: string) => {
  const hasNumber = /\d/.test(password);
  return password.length >= 6 && hasNumber;
};

export const validateSaId = (id: string) => {
  return /^\d{13}$/.test(id);
};

export const validatePhoneNumber = (phone: string) => {
  // Basic validation for South African phone numbers
  // Accepts formats like: 0821234567, 082 123 4567, +27 82 123 4567
  return /^(0|(\+27))?[0-9]{9,10}$/.test(phone.replace(/\s+/g, ''));
};
