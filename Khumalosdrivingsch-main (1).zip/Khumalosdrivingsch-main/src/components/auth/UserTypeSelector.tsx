
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface UserTypeSelectorProps {
  userType: "student" | "instructor" | "admin";
  onUserTypeChange: (value: "student" | "instructor" | "admin") => void;
  setShowAdminField: (show: boolean) => void;
}

export const UserTypeSelector = ({ 
  userType, 
  onUserTypeChange, 
  setShowAdminField 
}: UserTypeSelectorProps) => {
  return (
    <div className="space-y-2">
      <Label>User Type</Label>
      <RadioGroup
        value={userType}
        onValueChange={(value: "student" | "instructor" | "admin") => {
          onUserTypeChange(value);
          setShowAdminField(value === "admin");
        }}
        className="flex flex-wrap space-x-4"
      >
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="student" id="student" />
          <Label htmlFor="student">Student</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="instructor" id="instructor" />
          <Label htmlFor="instructor">Instructor</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="admin" id="admin" />
          <Label htmlFor="admin">Administrator</Label>
        </div>
      </RadioGroup>
    </div>
  );
};
