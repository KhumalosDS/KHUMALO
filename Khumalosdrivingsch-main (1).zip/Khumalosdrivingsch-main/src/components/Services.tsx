import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const services = [
  {
    title: "Learner's License",
    description: "Comprehensive preparation for your learner's license test with study materials and practice tests. This is included in your Driver's license package at no additional cost.",
  },
  {
    title: "Driving Lessons",
    description: "One-on-one practical driving lessons with experienced instructors. Unlimited lessons until you are ready for your test.",
  },
  {
    title: "Test Preparation",
    description: "Free intensive preparation for your driver's license test including mock tests to ensure you're fully prepared.",
  },
];

export const Services = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container">
        <h2 className="text-4xl font-bold text-center mb-12 text-primary">Our Services</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service) => (
            <Card key={service.title} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-xl">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};