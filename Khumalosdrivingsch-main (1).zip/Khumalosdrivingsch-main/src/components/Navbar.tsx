
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Menu } from "lucide-react";
import { useState } from "react";

export const Navbar = () => {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="bg-white shadow-sm relative">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <span 
              className="text-xl font-bold text-primary cursor-pointer"
              onClick={() => navigate("/")}
            >
              Khumalos Driving School
            </span>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="h-6 w-6" />
            </Button>
          </div>

          {/* Desktop menu */}
          <div className="hidden md:flex items-center gap-4">
            <Button variant="ghost" onClick={() => navigate("/")}>Home</Button>
            <Button variant="ghost" onClick={() => navigate("/about")}>About</Button>
            <Button variant="ghost" onClick={() => navigate("/services")}>Services</Button>
            <Button variant="ghost" onClick={() => navigate("/contact")}>Contact</Button>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-16 left-0 right-0 bg-white shadow-lg z-50">
            <div className="flex flex-col p-4 space-y-2">
              <Button variant="ghost" onClick={() => { navigate("/"); setIsMenuOpen(false); }}>Home</Button>
              <Button variant="ghost" onClick={() => { navigate("/about"); setIsMenuOpen(false); }}>About</Button>
              <Button variant="ghost" onClick={() => { navigate("/services"); setIsMenuOpen(false); }}>Services</Button>
              <Button variant="ghost" onClick={() => { navigate("/contact"); setIsMenuOpen(false); }}>Contact</Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};
