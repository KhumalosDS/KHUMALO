
import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Edit, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EditBookingForm } from "./EditBookingForm";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

type Lesson = {
  id: string;
  student_id: string;
  instructor_id: string;
  lesson_date: string;
  status: "attended" | "missed" | "pending";
  lesson_type: "learners" | "beginner" | "intermediate" | "advanced";
  duration: number;
  notes: string | null;
  student_name?: string;
  instructor_name?: string;
};

interface BookingManagementProps {
  lessons: Lesson[];
  onEditBooking: (lesson: Lesson) => void;
  onDeleteBooking: (lesson: Lesson) => void;
}

export const BookingManagement = ({ 
  lessons, 
  onEditBooking, 
  onDeleteBooking 
}: BookingManagementProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Booking Management</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {lessons.map((lesson) => (
            <div key={lesson.id} className="flex items-center justify-between p-4 border rounded-md">
              <div>
                <div className="flex items-center space-x-2">
                  <span className={`w-3 h-3 rounded-full ${
                    lesson.status === "attended" ? "bg-green-500" : 
                    lesson.status === "missed" ? "bg-red-500" : "bg-yellow-500"
                  }`}></span>
                  <p className="font-medium">
                    {format(new Date(lesson.lesson_date), "PPP")} at {format(new Date(lesson.lesson_date), "p")}
                  </p>
                </div>
                <p className="text-sm mt-1">Student: {lesson.student_name}</p>
                <p className="text-sm">Instructor: {lesson.instructor_name}</p>
                <div className="flex space-x-2 mt-1">
                  <span className="text-xs bg-slate-200 px-2 py-1 rounded">{lesson.lesson_type}</span>
                  <span className="text-xs bg-slate-200 px-2 py-1 rounded">{lesson.duration} mins</span>
                  <span className="text-xs bg-slate-200 px-2 py-1 rounded capitalize">{lesson.status}</span>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button size="sm" variant="outline" onClick={() => onEditBooking(lesson)}>
                  <Edit className="h-4 w-4 mr-1" />
                  Edit
                </Button>
                <Button 
                  size="sm" 
                  variant="destructive" 
                  onClick={() => onDeleteBooking(lesson)}
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Cancel
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
