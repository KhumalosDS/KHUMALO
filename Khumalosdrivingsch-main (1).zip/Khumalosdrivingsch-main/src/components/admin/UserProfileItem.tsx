
import { Button } from "@/components/ui/button";
import { Edit, Trash2, Key } from "lucide-react";

export interface UserProfileItemProps {
  profile: {
    id: string;
    full_name: string;
    email: string | null;
    phone: string | null;
    user_type: "student" | "instructor" | "admin";
    sa_id_number: string;
    testing_ready?: boolean;
  };
  onEdit: (profile: UserProfileItemProps["profile"]) => void;
  onDelete: (profile: UserProfileItemProps["profile"]) => void;
  onResetPassword: (profile: UserProfileItemProps["profile"]) => void;
}

export const UserProfileItem = ({ 
  profile, 
  onEdit, 
  onDelete,
  onResetPassword
}: UserProfileItemProps) => {
  return (
    <div className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-md gap-4">
      <div>
        <p className="font-medium">{profile.full_name}</p>
        <p className="text-sm text-muted-foreground">{profile.email || "No email provided"}</p>
        <div className="flex flex-wrap gap-2 mt-1">
          <span className="text-xs bg-slate-200 px-2 py-1 rounded">{profile.user_type}</span>
          <span className="text-xs bg-slate-200 px-2 py-1 rounded">ID: {profile.sa_id_number}</span>
          {profile.phone && (
            <span className="text-xs bg-slate-200 px-2 py-1 rounded">Phone: {profile.phone}</span>
          )}
          {profile.testing_ready && (
            <span className="text-xs bg-green-200 text-green-800 px-2 py-1 rounded">Ready for Testing</span>
          )}
        </div>
      </div>
      <div className="flex space-x-2 mt-3 md:mt-0">
        <Button 
          size="sm" 
          variant="outline" 
          onClick={(e) => {
            e.stopPropagation();
            onResetPassword(profile);
          }}
        >
          <Key className="h-4 w-4 mr-1" />
          Reset
        </Button>
        <Button 
          size="sm" 
          variant="outline" 
          onClick={(e) => {
            e.stopPropagation();
            onEdit(profile);
          }}
        >
          <Edit className="h-4 w-4 mr-1" />
          Edit
        </Button>
        <Button 
          size="sm" 
          variant="destructive" 
          onClick={(e) => {
            e.stopPropagation();
            onDelete(profile);
          }}
        >
          <Trash2 className="h-4 w-4 mr-1" />
          Delete
        </Button>
      </div>
    </div>
  );
};
