
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2 } from "lucide-react";
import { UserManagementTab } from "./dashboard/UserManagementTab";
import { BookingManagementTab } from "./dashboard/BookingManagementTab";
import { CreateBookingTab } from "./dashboard/CreateBookingTab";
import { ResetUserPasswordForm } from "./ResetUserPasswordForm";

type Profile = {
  id: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  user_type: "student" | "instructor" | "admin";
  sa_id_number: string;
  testing_ready?: boolean;
};

type Lesson = {
  id: string;
  student_id: string;
  instructor_id: string;
  lesson_date: string;
  status: "attended" | "missed" | "pending";
  lesson_type: "learners" | "beginner" | "intermediate" | "advanced";
  duration: number;
  notes: string | null;
  student_name?: string;
  instructor_name?: string;
};

interface AdminDashboardTabsProps {
  profiles: Profile[];
  lessons: Lesson[];
  instructors: Profile[];
  students: Profile[];
  isLoading: boolean;
  onDataRefresh: () => Promise<void>;
}

export const AdminDashboardTabs = ({
  profiles,
  lessons,
  instructors,
  students,
  isLoading,
  onDataRefresh
}: AdminDashboardTabsProps) => {
  if (isLoading) {
    return (
      <div className="flex h-32 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <>
      <Tabs defaultValue="users">
        <TabsList className="mb-4">
          <TabsTrigger value="users">Manage Users</TabsTrigger>
          <TabsTrigger value="lessons">Manage Bookings</TabsTrigger>
          <TabsTrigger value="new-booking">Create Booking</TabsTrigger>
        </TabsList>
        
        <TabsContent value="users">
          <UserManagementTab 
            profiles={profiles}
            onDataRefresh={onDataRefresh}
          />
        </TabsContent>
        
        <TabsContent value="lessons">
          <BookingManagementTab
            lessons={lessons}
            onDataRefresh={onDataRefresh}
          />
        </TabsContent>
        
        <TabsContent value="new-booking">
          <CreateBookingTab
            students={students}
            instructors={instructors}
            onDataRefresh={onDataRefresh}
          />
        </TabsContent>
      </Tabs>
    </>
  );
};
