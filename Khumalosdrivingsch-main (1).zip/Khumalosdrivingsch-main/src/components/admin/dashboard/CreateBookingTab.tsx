
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CreateBookingForm } from "../CreateBookingForm";
import { Loader2 } from "lucide-react";

type Profile = {
  id: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  user_type: "student" | "instructor" | "admin";
  sa_id_number: string;
  testing_ready?: boolean;
};

interface CreateBookingTabProps {
  students: Profile[];
  instructors: Profile[];
  onDataRefresh: () => Promise<void>;
}

export const CreateBookingTab = ({ students, instructors, onDataRefresh }: CreateBookingTabProps) => {
  const [bookingLoading, setBookingLoading] = useState(false);
  const { toast } = useToast();

  const handleCreateBooking = async (
    studentId: string, 
    instructorId: string, 
    date: string, 
    type: "learners" | "beginner" | "intermediate" | "advanced"
  ) => {
    setBookingLoading(true);
    
    try {
      // Check if this is a new student that needs to be created
      if (studentId.startsWith("new-student:")) {
        const parts = studentId.split(":");
        const studentName = parts[1];
        const studentEmail = parts[2] || null;
        
        // Create a new student profile
        const { data: newStudent, error: profileError } = await supabase
          .from("profiles")
          .insert({
            id: crypto.randomUUID(),
            full_name: studentName,
            email: studentEmail,
            user_type: "student",
            sa_id_number: Date.now().toString().substring(0, 13) // Temporary ID for demo
          })
          .select();
          
        if (profileError) throw profileError;
        
        // Use the new student ID
        studentId = newStudent[0].id;
      }
      
      // Now create the booking
      const { error } = await supabase
        .from("lessons")
        .insert({
          student_id: studentId,
          instructor_id: instructorId,
          lesson_date: date,
          lesson_type: type,
          status: "pending",
          duration: 60,
        });
        
      if (error) throw error;
      
      toast({
        title: "Success",
        description: "Booking created successfully",
      });
      
      await onDataRefresh(); // Ensure data refresh completes
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setBookingLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create New Booking</CardTitle>
      </CardHeader>
      <CardContent>
        <CreateBookingForm 
          students={students}
          instructors={instructors}
          onCreateBooking={handleCreateBooking}
        />
        {bookingLoading && (
          <div className="flex justify-center mt-4">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        )}
      </CardContent>
    </Card>
  );
};
