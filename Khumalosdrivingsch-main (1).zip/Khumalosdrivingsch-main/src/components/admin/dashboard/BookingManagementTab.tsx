
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { BookingManagement } from "../BookingManagement";
import { EditBookingForm } from "../EditBookingForm";

type Lesson = {
  id: string;
  student_id: string;
  instructor_id: string;
  lesson_date: string;
  status: "attended" | "missed" | "pending";
  lesson_type: "learners" | "beginner" | "intermediate" | "advanced";
  duration: number;
  notes: string | null;
  student_name?: string;
  instructor_name?: string;
};

interface BookingManagementTabProps {
  lessons: Lesson[];
  onDataRefresh: () => Promise<void>;
}

export const BookingManagementTab = ({ lessons, onDataRefresh }: BookingManagementTabProps) => {
  const [isBookingEditOpen, setIsBookingEditOpen] = useState(false);
  const [currentLesson, setCurrentLesson] = useState<Lesson | null>(null);
  const [isBookingDeleteAlertOpen, setIsBookingDeleteAlertOpen] = useState(false);
  const [lessonToDelete, setLessonToDelete] = useState<Lesson | null>(null);
  const { toast } = useToast();

  const handleEditBooking = (lesson: Lesson) => {
    setCurrentLesson(lesson);
    setIsBookingEditOpen(true);
  };
  
  const handleSaveBooking = async (
    id: string, 
    date: string, 
    type: "learners" | "beginner" | "intermediate" | "advanced",
    status: "attended" | "missed" | "pending",
    notes: string
  ) => {
    try {
      const { error } = await supabase
        .from("lessons")
        .update({
          lesson_date: date,
          lesson_type: type,
          status: status,
          notes: notes
        })
        .eq("id", id);
        
      if (error) throw error;
      
      toast({
        title: "Success",
        description: "Booking updated successfully",
      });
      
      setIsBookingEditOpen(false);
      await onDataRefresh(); // Ensure data refresh completes
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };
  
  const handleDeleteBooking = (lesson: Lesson) => {
    setLessonToDelete(lesson);
    setIsBookingDeleteAlertOpen(true);
  };
  
  const confirmDeleteBooking = async () => {
    if (!lessonToDelete) return;
    
    try {
      const { error } = await supabase
        .from("lessons")
        .delete()
        .eq("id", lessonToDelete.id);
        
      if (error) throw error;
      
      toast({
        title: "Success",
        description: "Booking cancelled successfully",
      });
      
      setIsBookingDeleteAlertOpen(false);
      await onDataRefresh(); // Ensure data refresh completes
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <>
      <BookingManagement 
        lessons={lessons}
        onEditBooking={handleEditBooking}
        onDeleteBooking={handleDeleteBooking}
      />

      {/* Edit Booking Dialog */}
      <Dialog open={isBookingEditOpen} onOpenChange={setIsBookingEditOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Booking</DialogTitle>
          </DialogHeader>
          {currentLesson && (
            <EditBookingForm 
              lesson={currentLesson}
              onSave={handleSaveBooking}
              onCancel={() => setIsBookingEditOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>
      
      {/* Delete Booking Confirmation */}
      <AlertDialog open={isBookingDeleteAlertOpen} onOpenChange={setIsBookingDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action will permanently cancel this booking.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDeleteBooking} 
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Cancel Booking
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};
