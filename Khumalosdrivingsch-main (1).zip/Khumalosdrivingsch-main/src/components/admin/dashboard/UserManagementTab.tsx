
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Loader2 } from "lucide-react";
import { UserManagement } from "../UserManagement";
import { EditUserForm } from "../EditUserForm";
import { ResetUserPasswordForm } from "../ResetUserPasswordForm";

type Profile = {
  id: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  user_type: "student" | "instructor" | "admin";
  sa_id_number: string;
  testing_ready?: boolean;
};

interface UserManagementTabProps {
  profiles: Profile[];
  onDataRefresh: () => Promise<void>;
}

export const UserManagementTab = ({ profiles, onDataRefresh }: UserManagementTabProps) => {
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isPasswordResetOpen, setIsPasswordResetOpen] = useState(false);
  const [currentProfile, setCurrentProfile] = useState<Profile | null>(null);
  const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);
  const [profileToDelete, setProfileToDelete] = useState<Profile | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const { toast } = useToast();

  const handleEditProfile = (profile: Profile) => {
    console.log("Edit profile:", profile);
    setCurrentProfile(profile);
    setIsEditDialogOpen(true);
  };
  
  const handleDeleteProfile = (profile: Profile) => {
    console.log("Delete profile:", profile);
    setProfileToDelete(profile);
    setIsDeleteAlertOpen(true);
  };
  
  const handleResetPassword = (profile: Profile) => {
    console.log("Reset password:", profile);
    setCurrentProfile(profile);
    setIsPasswordResetOpen(true);
  };
  
  const confirmDeleteProfile = async () => {
    if (!profileToDelete) return;
    
    setIsDeleting(true);
    
    try {
      console.log("Deleting profile:", profileToDelete.id);
      
      // Check if there are related lessons
      const { data: lessonData, error: lessonCheckError } = await supabase
        .from("lessons")
        .select("id")
        .or(`student_id.eq.${profileToDelete.id},instructor_id.eq.${profileToDelete.id}`)
        .limit(1);
      
      if (lessonCheckError) {
        console.error("Error checking lessons:", lessonCheckError);
        throw lessonCheckError;
      }
      
      // Delete related lessons if they exist
      if (lessonData && lessonData.length > 0) {
        console.log("Deleting related lessons");
        const { error: lessonsError } = await supabase
          .from("lessons")
          .delete()
          .or(`student_id.eq.${profileToDelete.id},instructor_id.eq.${profileToDelete.id}`);
        
        if (lessonsError) {
          console.error("Error deleting lessons:", lessonsError);
          throw lessonsError;
        }
      }
      
      // Delete the profile
      const { error: profileError } = await supabase
        .from("profiles")
        .delete()
        .eq("id", profileToDelete.id);
        
      if (profileError) {
        console.error("Error deleting profile:", profileError);
        throw profileError;
      }
      
      console.log("Profile deleted successfully");
      toast({
        title: "Success",
        description: "User deleted successfully",
      });
      
      setIsDeleteAlertOpen(false);
      setProfileToDelete(null);
      await onDataRefresh(); // Use await to ensure data is refreshed before continuing
    } catch (error: any) {
      console.error("Delete error:", error);
      toast({
        title: "Error",
        description: "Failed to delete user: " + error.message,
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <>
      <UserManagement 
        profiles={profiles} 
        onEditProfile={handleEditProfile}
        onDeleteProfile={handleDeleteProfile}
        onResetPassword={handleResetPassword}
        onProfilesRefresh={onDataRefresh}
      />

      {/* Edit Profile Dialog */}
      {currentProfile && (
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Edit User Profile</DialogTitle>
            </DialogHeader>
            <EditUserForm 
              profile={currentProfile}
              onSuccess={async () => {
                setIsEditDialogOpen(false);
                await onDataRefresh(); // Ensure data refresh completes
              }}
              onCancel={() => setIsEditDialogOpen(false)}
            />
          </DialogContent>
        </Dialog>
      )}
      
      {/* Reset Password Dialog */}
      {currentProfile && (
        <Dialog open={isPasswordResetOpen} onOpenChange={setIsPasswordResetOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Reset User Password</DialogTitle>
            </DialogHeader>
            <ResetUserPasswordForm
              profile={currentProfile}
              onSuccess={() => {
                setIsPasswordResetOpen(false);
              }}
              onCancel={() => setIsPasswordResetOpen(false)}
            />
          </DialogContent>
        </Dialog>
      )}
      
      {/* Delete Profile Confirmation */}
      <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action will permanently delete the user {profileToDelete?.full_name}.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDeleteProfile} 
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={isDeleting}
            >
              {isDeleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};
