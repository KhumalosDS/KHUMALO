
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Save } from "lucide-react";

type Lesson = {
  id: string;
  student_id: string;
  instructor_id: string;
  lesson_date: string;
  status: "attended" | "missed" | "pending";
  lesson_type: "learners" | "beginner" | "intermediate" | "advanced";
  duration: number;
  notes: string | null;
  student_name?: string;
  instructor_name?: string;
};

interface EditBookingFormProps {
  lesson: Lesson;
  onSave: (
    id: string, 
    date: string, 
    type: "learners" | "beginner" | "intermediate" | "advanced",
    status: "attended" | "missed" | "pending",
    notes: string
  ) => Promise<void>;
  onCancel: () => void;
}

export const EditBookingForm = ({ lesson, onSave, onCancel }: EditBookingFormProps) => {
  const [lessonDate, setLessonDate] = useState(lesson.lesson_date.substring(0, 16));
  const [lessonType, setLessonType] = useState<"learners" | "beginner" | "intermediate" | "advanced">(lesson.lesson_type);
  const [lessonStatus, setLessonStatus] = useState<"attended" | "missed" | "pending">(lesson.status);
  const [lessonNotes, setLessonNotes] = useState(lesson.notes || "");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      await onSave(
        lesson.id,
        new Date(lessonDate).toISOString(),
        lessonType,
        lessonStatus,
        lessonNotes
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="edit-booking-date">Date and Time</Label>
        <Input
          id="edit-booking-date"
          type="datetime-local"
          value={lessonDate}
          onChange={(e) => setLessonDate(e.target.value)}
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="edit-booking-type">Lesson Type</Label>
        <Select 
          value={lessonType} 
          onValueChange={(value) => setLessonType(value as "learners" | "beginner" | "intermediate" | "advanced")}
        >
          <SelectTrigger id="edit-booking-type">
            <SelectValue placeholder="Select lesson type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="learners">Learners</SelectItem>
            <SelectItem value="beginner">Beginner</SelectItem>
            <SelectItem value="intermediate">Intermediate</SelectItem>
            <SelectItem value="advanced">Advanced</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="edit-booking-status">Status</Label>
        <Select 
          value={lessonStatus} 
          onValueChange={(value) => setLessonStatus(value as "attended" | "missed" | "pending")}
        >
          <SelectTrigger id="edit-booking-status">
            <SelectValue placeholder="Select status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="attended">Attended</SelectItem>
            <SelectItem value="missed">Missed</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="edit-booking-notes">Notes</Label>
        <Textarea
          id="edit-booking-notes"
          value={lessonNotes}
          onChange={(e) => setLessonNotes(e.target.value)}
          placeholder="Add any notes about this booking..."
        />
      </div>

      <div className="flex justify-end space-x-2 pt-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Save Changes
            </>
          )}
        </Button>
      </div>
    </form>
  );
};
