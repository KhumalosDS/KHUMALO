
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Save } from 'lucide-react';
import { supabase } from "@/integrations/supabase/client";
import { validatePhoneNumber } from "@/components/auth/validation";

type Profile = {
  id: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  user_type: "student" | "instructor" | "admin";
  sa_id_number: string;
  testing_ready?: boolean;
};

export const EditUserForm = ({ 
  profile, 
  onSuccess,
  onCancel 
}: { 
  profile: Profile; 
  onSuccess: () => void;
  onCancel: () => void;
}) => {
  const [name, setName] = useState(profile.full_name);
  const [email, setEmail] = useState(profile.email || '');
  const [phoneNumber, setPhoneNumber] = useState(profile.phone || '');
  const [userType, setUserType] = useState<"student" | "instructor" | "admin">(profile.user_type);
  const [testingReady, setTestingReady] = useState(profile.testing_ready || false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Validate required fields
      if (!name) {
        throw new Error("Name is required");
      }

      // Validate phone number if provided
      if (phoneNumber && !validatePhoneNumber(phoneNumber)) {
        throw new Error("Please enter a valid South African phone number");
      }

      console.log("Updating profile with data:", {
        id: profile.id,
        full_name: name,
        email: email || null,
        phone: phoneNumber || null,
        user_type: userType,
        testing_ready: testingReady
      });

      const { data, error } = await supabase
        .from("profiles")
        .update({
          full_name: name,
          email: email || null,
          phone: phoneNumber || null,
          user_type: userType,
          testing_ready: testingReady
        })
        .eq("id", profile.id)
        .select();
        
      if (error) {
        console.error("Update error:", error);
        throw error;
      }
      
      console.log("Profile updated successfully:", data);
      
      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
      
      onSuccess();
    } catch (error: any) {
      console.error("Form submission error:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to update profile",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="edit-name">Full Name</Label>
        <Input
          id="edit-name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="edit-email">Email Address (Optional)</Label>
        <Input
          id="edit-email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="edit-phone">Phone Number (Optional)</Label>
        <Input
          id="edit-phone"
          value={phoneNumber}
          onChange={(e) => setPhoneNumber(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="edit-type">User Type</Label>
        <Select 
          value={userType} 
          onValueChange={(value) => setUserType(value as "student" | "instructor" | "admin")}
        >
          <SelectTrigger id="edit-type">
            <SelectValue placeholder="Select user type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="student">Student</SelectItem>
            <SelectItem value="instructor">Instructor</SelectItem>
            <SelectItem value="admin">Admin</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {userType === "student" && (
        <div className="flex items-center space-x-2">
          <Switch 
            id="testing-ready" 
            checked={testingReady}
            onCheckedChange={setTestingReady}
          />
          <Label htmlFor="testing-ready">Mark as Ready for Testing</Label>
        </div>
      )}

      <div className="flex justify-end space-x-2 pt-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Save Changes
            </>
          )}
        </Button>
      </div>
    </form>
  );
};
