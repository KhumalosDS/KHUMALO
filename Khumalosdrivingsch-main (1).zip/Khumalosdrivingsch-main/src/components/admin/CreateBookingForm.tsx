
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, UserPlus } from "lucide-react";

type Profile = {
  id: string;
  full_name: string;
};

interface CreateBookingFormProps {
  students: Profile[];
  instructors: Profile[];
  onCreateBooking: (
    studentId: string,
    instructorId: string,
    date: string,
    type: "learners" | "beginner" | "intermediate" | "advanced"
  ) => Promise<void>;
}

export const CreateBookingForm = ({ 
  students, 
  instructors, 
  onCreateBooking 
}: CreateBookingFormProps) => {
  const [selectedStudent, setSelectedStudent] = useState("");
  const [selectedInstructor, setSelectedInstructor] = useState("");
  const [lessonDate, setLessonDate] = useState("");
  const [lessonType, setLessonType] = useState<"learners" | "beginner" | "intermediate" | "advanced">("learners");
  const [studentName, setStudentName] = useState("");
  const [studentEmail, setStudentEmail] = useState("");
  const [isNewStudent, setIsNewStudent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      if (!selectedInstructor || !lessonDate || !lessonType) {
        throw new Error("All fields except Email are required");
      }
      
      let finalStudentId = selectedStudent;
      
      if (isNewStudent) {
        if (!studentName) {
          throw new Error("Student name is required");
        }
        
        // Here we would create a new student profile
        // This would be handled in the parent component
        // For now we just pass the information
        await onCreateBooking(
          "new-student:" + studentName + ":" + studentEmail,
          selectedInstructor,
          new Date(lessonDate).toISOString(),
          lessonType
        );
      } else {
        if (!selectedStudent) {
          throw new Error("Please select a student");
        }
        
        await onCreateBooking(
          selectedStudent,
          selectedInstructor,
          new Date(lessonDate).toISOString(),
          lessonType
        );
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <div className="flex items-center space-x-2 mb-2">
          <Label htmlFor="isNewStudent">New Student</Label>
          <input 
            type="checkbox" 
            id="isNewStudent"
            checked={isNewStudent}
            onChange={(e) => setIsNewStudent(e.target.checked)}
            className="h-4 w-4"
          />
        </div>

        {isNewStudent ? (
          <>
            <div className="space-y-2">
              <Label htmlFor="studentName">Student Name</Label>
              <Input
                id="studentName"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="studentEmail">Student Email (Optional)</Label>
              <Input
                id="studentEmail"
                type="email"
                value={studentEmail}
                onChange={(e) => setStudentEmail(e.target.value)}
              />
            </div>
          </>
        ) : (
          <div className="space-y-2">
            <Label htmlFor="student">Student</Label>
            <Select value={selectedStudent} onValueChange={setSelectedStudent} required>
              <SelectTrigger>
                <SelectValue placeholder="Select a student" />
              </SelectTrigger>
              <SelectContent>
                {students.map(student => (
                  <SelectItem key={student.id} value={student.id}>
                    {student.full_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="instructor">Instructor</Label>
        <Select value={selectedInstructor} onValueChange={setSelectedInstructor} required>
          <SelectTrigger>
            <SelectValue placeholder="Select an instructor" />
          </SelectTrigger>
          <SelectContent>
            {instructors.map(instructor => (
              <SelectItem key={instructor.id} value={instructor.id}>
                {instructor.full_name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="date">Date and Time</Label>
        <Input
          id="date"
          type="datetime-local"
          value={lessonDate}
          onChange={(e) => setLessonDate(e.target.value)}
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="type">Lesson Type</Label>
        <Select 
          value={lessonType} 
          onValueChange={(value) => setLessonType(value as "learners" | "beginner" | "intermediate" | "advanced")}
          required
        >
          <SelectTrigger>
            <SelectValue placeholder="Select a lesson type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="learners">Learners</SelectItem>
            <SelectItem value="beginner">Beginner</SelectItem>
            <SelectItem value="intermediate">Intermediate</SelectItem>
            <SelectItem value="advanced">Advanced</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <Button type="submit" className="w-full" disabled={isLoading}>
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" /> 
            Creating Booking...
          </>
        ) : (
          <>
            <UserPlus className="mr-2 h-4 w-4" />
            Create Booking
          </>
        )}
      </Button>
    </form>
  );
};
