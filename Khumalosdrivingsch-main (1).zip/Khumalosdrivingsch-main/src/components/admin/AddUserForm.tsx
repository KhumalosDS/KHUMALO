
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Loader2, UserPlus } from 'lucide-react';
import { supabase } from "@/integrations/supabase/client";
import { validateSaId, validatePhoneNumber } from "@/components/auth/validation";

export const AddUserForm = ({ onSuccess }: { onSuccess: () => void }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [saIdNumber, setSaIdNumber] = useState('');
  const [userType, setUserType] = useState<"student" | "instructor" | "admin">("student");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Validate required fields
      if (!name || !saIdNumber || !phoneNumber) {
        throw new Error("Name, ID number, and phone number are required");
      }

      // Validate SA ID number
      if (!validateSaId(saIdNumber)) {
        throw new Error("Please enter a valid 13-digit South African ID number");
      }

      // Validate phone number
      if (!validatePhoneNumber(phoneNumber)) {
        throw new Error("Please enter a valid South African phone number");
      }

      // Check if SA ID number is already in use
      const { data: existingUsers, error: checkError } = await supabase
        .from("profiles")
        .select("id")
        .eq("sa_id_number", saIdNumber);
      
      if (checkError) {
        console.error("Could not verify ID number uniqueness:", checkError);
        throw new Error("Could not verify ID number uniqueness");
      }
      
      if (existingUsers && existingUsers.length > 0) {
        throw new Error("An account with this ID number already exists");
      }

      // Create profile directly (without auth account)
      const { data: profileData, error: profileError } = await supabase
        .from("profiles")
        .insert({
          id: crypto.randomUUID(), // Generate UUID for the user
          full_name: name,
          email: email || null, // Make email optional
          phone: phoneNumber,
          sa_id_number: saIdNumber,
          user_type: userType
        })
        .select();

      if (profileError) {
        console.error("Profile creation error:", profileError);
        throw profileError;
      }

      console.log("User added successfully:", profileData);
      toast({
        title: "Success",
        description: `${userType} added successfully`,
      });

      // Reset form
      setName('');
      setEmail('');
      setPhoneNumber('');
      setSaIdNumber('');
      setUserType("student");
      
      if (onSuccess) onSuccess();
      
    } catch (error: any) {
      console.error("Form submission error:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to add user",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Full Name</Label>
        <Input
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">Email Address (Optional)</Label>
        <Input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="phoneNumber">Phone Number</Label>
        <Input
          id="phoneNumber"
          value={phoneNumber}
          onChange={(e) => setPhoneNumber(e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="saIdNumber">South African ID Number</Label>
        <Input
          id="saIdNumber"
          value={saIdNumber}
          onChange={(e) => setSaIdNumber(e.target.value)}
          maxLength={13}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="userType">User Type</Label>
        <Select value={userType} onValueChange={(value) => setUserType(value as "student" | "instructor" | "admin")}>
          <SelectTrigger id="userType">
            <SelectValue placeholder="Select user type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="student">Student</SelectItem>
            <SelectItem value="instructor">Instructor</SelectItem>
            <SelectItem value="admin">Admin</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Button type="submit" className="w-full" disabled={isLoading}>
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Adding User...
          </>
        ) : (
          <>
            <UserPlus className="mr-2 h-4 w-4" />
            Add User
          </>
        )}
      </Button>
    </form>
  );
};
