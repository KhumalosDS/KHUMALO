
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";

type Profile = {
  id: string;
  full_name: string;
  email: string | null;
};

export const ResetUserPasswordForm = ({ 
  profile, 
  onSuccess,
  onCancel
}: { 
  profile: Profile;
  onSuccess: () => void;
  onCancel: () => void;
}) => {
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const { toast } = useToast();

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    
    if (!profile.email) {
      setErrorMessage("User has no email address associated");
      return;
    }
    
    if (newPassword !== confirmNewPassword) {
      setErrorMessage("Passwords do not match");
      return;
    }
    
    if (newPassword.length < 6) {
      setErrorMessage("Password must be at least 6 characters");
      return;
    }
    
    setIsLoading(true);
    
    try {
      // For admin password reset we need to use server-side admin functions
      // Instead, we'll send a password reset email to the user
      const { error } = await supabase.auth.resetPasswordForEmail(profile.email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) throw error;
      
      toast({
        title: "Password Reset Email Sent",
        description: `A password reset link has been sent to ${profile.email}`,
      });
      
      onSuccess();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to send password reset email",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // If user has no email, show an error
  if (!profile.email) {
    return (
      <div className="p-4 bg-destructive/10 rounded-md text-center">
        <p className="text-destructive font-medium">
          This user has no email address and cannot receive a password reset link.
        </p>
        <Button onClick={onCancel} className="mt-4">
          Close
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={handleResetPassword} className="space-y-4">
      <div className="space-y-2">
        <Label>User</Label>
        <div className="p-2 bg-muted rounded-md">
          <p className="font-medium">{profile.full_name}</p>
          <p className="text-sm text-muted-foreground">{profile.email}</p>
        </div>
      </div>

      <div className="p-4 bg-muted rounded-md">
        <p className="text-sm">
          A password reset link will be sent to the user's email address. 
          The user will need to click the link to set a new password.
        </p>
      </div>

      {errorMessage && (
        <p className="text-sm text-destructive">{errorMessage}</p>
      )}

      <div className="flex justify-end space-x-2 pt-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Sending...
            </>
          ) : "Send Reset Link"}
        </Button>
      </div>
    </form>
  );
};
