
import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AddUserForm } from "./AddUserForm";
import { UserProfileItem } from "./UserProfileItem";

type Profile = {
  id: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  user_type: "student" | "instructor" | "admin";
  sa_id_number: string;
  testing_ready?: boolean;
};

interface UserManagementProps {
  profiles: Profile[];
  onEditProfile: (profile: Profile) => void;
  onDeleteProfile: (profile: Profile) => void;
  onResetPassword?: (profile: Profile) => void;
  onProfilesRefresh: () => void;
}

export const UserManagement = ({ 
  profiles, 
  onEditProfile, 
  onDeleteProfile,
  onResetPassword = () => {},
  onProfilesRefresh
}: UserManagementProps) => {
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>User Management</CardTitle>
        <Button onClick={() => setIsAddUserOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add User
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {profiles.map((profile) => (
            <UserProfileItem 
              key={profile.id} 
              profile={profile} 
              onEdit={() => onEditProfile(profile)}
              onDelete={() => onDeleteProfile(profile)}
              onResetPassword={() => onResetPassword(profile)}
            />
          ))}
        </div>
      </CardContent>

      {/* Add User Dialog */}
      <Dialog open={isAddUserOpen} onOpenChange={setIsAddUserOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add New User</DialogTitle>
          </DialogHeader>
          <AddUserForm onSuccess={() => {
            setIsAddUserOpen(false);
            onProfilesRefresh();
          }} />
        </DialogContent>
      </Dialog>
    </Card>
  );
};
