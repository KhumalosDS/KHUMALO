
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

export const Hero = () => {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-[600px] flex items-center">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?ixlib=rb-4.0.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80')] bg-cover bg-center">
        <div className="absolute inset-0 bg-primary/70"></div>
      </div>
      <div className="container relative z-10">
        <div className="max-w-2xl text-white">
          <h1 className="text-5xl font-bold mb-6">Start Your Driving Journey the Khumalos way</h1>
          <p className="text-xl mb-8">Professional and Affordable learning and driving instruction with experienced and patient instructors. Get your license to drive off with confidence.</p>
          <div className="flex gap-4">
            <Button 
              size="lg" 
              className="bg-secondary hover:bg-secondary/90 text-white text-lg px-8 py-6 transform hover:scale-105 transition-all shadow-lg"
              onClick={() => navigate("/services")}
            >
              Our Services
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-white border-white hover:bg-white/20 text-lg px-8 py-6 transform hover:scale-105 transition-all shadow-lg"
              onClick={() => navigate("/contact")}
            >
              Contact Us
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
