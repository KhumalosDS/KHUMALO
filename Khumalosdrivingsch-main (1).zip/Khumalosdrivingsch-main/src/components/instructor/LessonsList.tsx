
import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Check, X } from "lucide-react";
import { LessonCard } from "./LessonCard";
import { supabase } from "@/integrations/supabase/client";
import { TestReadyButton } from "./TestReadyButton";

interface LessonsListProps {
  lessons: Array<{
    id: string;
    student_id: string;
    student_name?: string;
    lesson_type: string;
    lesson_date: string;
    status: "pending" | "attended" | "missed";
    duration: number;
  }>;
  onUpdateStatus: (lessonId: string, status: "attended" | "missed") => void;
}

export const LessonsList = ({ lessons, onUpdateStatus }: LessonsListProps) => {
  const [studentReadyStatus, setStudentReadyStatus] = useState<Record<string, boolean>>({});
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  useEffect(() => {
    const fetchStudentStatus = async () => {
      // Get unique student IDs
      const studentIds = [...new Set(lessons.map(lesson => lesson.student_id))];
      
      if (studentIds.length === 0) return;
      
      const { data, error } = await supabase
        .from("profiles")
        .select("id, testing_ready")
        .in("id", studentIds);
        
      if (error) {
        console.error("Error fetching student testing status:", error);
        return;
      }
      
      const statusMap: Record<string, boolean> = {};
      if (data) {
        data.forEach(profile => {
          statusMap[profile.id] = profile.testing_ready || false;
        });
      }
      
      setStudentReadyStatus(statusMap);
    };
    
    fetchStudentStatus();
    
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [lessons]);

  const refreshStudentStatus = async () => {
    const studentIds = [...new Set(lessons.map(lesson => lesson.student_id))];
      
    if (studentIds.length === 0) return;
    
    const { data, error } = await supabase
      .from("profiles")
      .select("id, testing_ready")
      .in("id", studentIds);
      
    if (error) {
      console.error("Error fetching student testing status:", error);
      return;
    }
    
    const statusMap: Record<string, boolean> = {};
    if (data) {
      data.forEach(profile => {
        statusMap[profile.id] = profile.testing_ready || false;
      });
    }
    
    setStudentReadyStatus(statusMap);
  };

  // Group lessons by student
  const studentLessons: Record<string, typeof lessons> = {};
  lessons.forEach(lesson => {
    const studentId = lesson.student_id;
    if (!studentLessons[studentId]) {
      studentLessons[studentId] = [];
    }
    studentLessons[studentId].push(lesson);
  });

  if (isMobile) {
    return (
      <div className="space-y-4">
        {lessons.map((lesson) => (
          <LessonCard
            key={lesson.id}
            lesson={lesson}
            onUpdateStatus={onUpdateStatus}
          />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {Object.entries(studentLessons).map(([studentId, studentLessons]) => (
        <Card key={studentId} className="overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between bg-slate-50 py-3">
            <CardTitle className="text-lg">{studentLessons[0].student_name || 'Unknown Student'}</CardTitle>
            <TestReadyButton 
              studentId={studentId}
              studentName={studentLessons[0].student_name || 'Unknown Student'}
              isReady={studentReadyStatus[studentId] || false}
              onStatusChange={refreshStudentStatus}
            />
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Lesson Type</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {studentLessons.map((lesson) => (
                  <TableRow key={lesson.id}>
                    <TableCell>{format(new Date(lesson.lesson_date), 'PPP p')}</TableCell>
                    <TableCell className="capitalize">{lesson.lesson_type}</TableCell>
                    <TableCell>{lesson.duration} mins</TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        lesson.status === 'attended' ? 'bg-green-100 text-green-800' :
                        lesson.status === 'missed' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {lesson.status}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      {lesson.status === 'pending' && (
                        <div className="flex justify-end space-x-2">
                          <Button size="sm" variant="outline" onClick={() => onUpdateStatus(lesson.id, 'attended')}>
                            <Check className="h-4 w-4 mr-1" />
                            Attended
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => onUpdateStatus(lesson.id, 'missed')}>
                            <X className="h-4 w-4 mr-1" />
                            Missed
                          </Button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
