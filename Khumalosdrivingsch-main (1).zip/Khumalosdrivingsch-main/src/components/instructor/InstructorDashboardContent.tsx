
import { InstructorStats } from "@/components/instructor/InstructorStats";
import { LessonsList } from "@/components/instructor/LessonsList";

interface InstructorDashboardContentProps {
  stats: {
    totalLessons: number;
    completedLessons: number;
    pendingLessons: number;
    cancelledLessons: number;
    totalHours: number;
  };
  lessons: Array<{
    id: string;
    student_id: string;
    student_name?: string;
    lesson_type: string;
    lesson_date: string;
    status: "pending" | "attended" | "missed";
    duration: number;
  }>;
  onUpdateStatus: (lessonId: string, status: "attended" | "missed") => void;
}

export const InstructorDashboardContent = ({
  stats,
  lessons,
  onUpdateStatus,
}: InstructorDashboardContentProps) => {
  return (
    <>
      <InstructorStats stats={stats} />
      
      <h2 className="text-2xl font-bold mb-4">Upcoming Lessons</h2>
      <LessonsList 
        lessons={lessons} 
        onUpdateStatus={onUpdateStatus} 
      />
    </>
  );
};
