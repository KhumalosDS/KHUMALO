
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface Lesson {
  id: string;
  student_id: string;
  student_name?: string;
  lesson_type: string;
  lesson_date: string;
  status: "pending" | "attended" | "missed";
  duration: number;
}

interface LessonCardProps {
  lesson: Lesson;
  onUpdateStatus: (lessonId: string, status: "attended" | "missed") => void;
}

export const LessonCard = ({ lesson, onUpdateStatus }: LessonCardProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl">
          Lesson with {lesson.student_name}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <p className="text-muted-foreground">Lesson Type:</p>
            <p className="font-medium">{lesson.lesson_type}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Time:</p>
            <p className="font-medium">
              {format(new Date(lesson.lesson_date), "PPpp")}
            </p>
          </div>
          <div>
            <p className="text-muted-foreground">Status:</p>
            <p className="font-medium capitalize">{lesson.status}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Duration:</p>
            <p className="font-medium">{lesson.duration} minutes</p>
          </div>
          
          {lesson.status === "pending" && (
            <div className="flex gap-2">
              <Button
                onClick={() => onUpdateStatus(lesson.id, "attended")}
                className="flex-1"
              >
                Mark as Attended
              </Button>
              <Button
                onClick={() => onUpdateStatus(lesson.id, "missed")}
                variant="destructive"
                className="flex-1"
              >
                Mark as Missed
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
