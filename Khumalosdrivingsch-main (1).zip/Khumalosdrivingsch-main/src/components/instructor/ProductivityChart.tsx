
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

interface ProductivityChartProps {
  stats: {
    completedLessons: number;
    pendingLessons: number;
    cancelledLessons: number;
  };
}

export const ProductivityChart = ({ stats }: ProductivityChartProps) => {
  const data = [
    { name: "Completed", value: stats.completedLessons, color: "#10b981" },
    { name: "Pending", value: stats.pendingLessons, color: "#f59e0b" },
    { name: "Cancelled", value: stats.cancelledLessons, color: "#ef4444" }
  ].filter(item => item.value > 0);
  
  // If no data, show placeholder
  if (data.length === 0 || (stats.completedLessons === 0 && stats.pendingLessons === 0 && stats.cancelledLessons === 0)) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Productivity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-40 flex items-center justify-center text-muted-foreground">
            No lesson data available
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">Productivity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-40">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={30}
                outerRadius={60}
                paddingAngle={5}
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                labelLine={false}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value) => [`${value} lessons`, '']} 
                labelFormatter={() => ''}
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};
