
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface TestReadyButtonProps {
  studentId: string;
  studentName: string;
  isReady: boolean;
  onStatusChange: () => void;
}

export const TestReadyButton = ({ 
  studentId, 
  studentName, 
  isReady, 
  onStatusChange 
}: TestReadyButtonProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleMarkAsReady = async () => {
    setIsLoading(true);
    
    try {
      const { error } = await supabase
        .from("profiles")
        .update({ testing_ready: true })
        .eq("id", studentId);
        
      if (error) throw error;
      
      toast({
        title: "Success",
        description: `${studentName} has been marked as ready for testing`,
      });
      
      onStatusChange();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (isReady) {
    return (
      <Button 
        variant="outline" 
        size="sm" 
        className="bg-green-50 text-green-600 border-green-200 hover:bg-green-100 hover:text-green-700"
        disabled
      >
        <CheckCircle className="h-4 w-4 mr-2" />
        Ready for Testing
      </Button>
    );
  }

  return (
    <Button 
      variant="outline"
      size="sm"
      onClick={handleMarkAsReady}
      disabled={isLoading}
    >
      {isLoading ? (
        <>
          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          Updating...
        </>
      ) : (
        <>
          <CheckCircle className="h-4 w-4 mr-2" />
          Mark Ready for Testing
        </>
      )}
    </Button>
  );
};
