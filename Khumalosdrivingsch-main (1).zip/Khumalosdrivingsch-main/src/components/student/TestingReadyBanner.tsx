
import { AlertCircle, CheckCircle2 } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export interface TestingReadyBannerProps {
  isReadyForTesting: boolean;
}

export const TestingReadyBanner = ({ isReadyForTesting }: TestingReadyBannerProps) => {
  if (!isReadyForTesting) return null;
  
  return (
    <Alert className="mb-6 bg-green-50 border-green-200">
      <CheckCircle2 className="h-5 w-5 text-green-600" />
      <AlertTitle className="text-green-800">Ready for Testing</AlertTitle>
      <AlertDescription className="text-green-700">
        Your instructor has marked you as ready for your driver's test. 
        You may now contact the testing center to schedule your official driving test.
      </AlertDescription>
    </Alert>
  );
};
