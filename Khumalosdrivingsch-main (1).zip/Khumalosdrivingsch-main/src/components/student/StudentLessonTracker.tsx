
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";
import { Check, X, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

interface StudentLessonTrackerProps {
  studentId: string;
}

export const StudentLessonTracker = ({ studentId }: StudentLessonTrackerProps) => {
  const [lessons, setLessons] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    attended: 0,
    missed: 0,
    pending: 0,
    total: 0
  });

  useEffect(() => {
    const fetchLessons = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from("lessons")
          .select(`
            *,
            profiles!lessons_instructor_id_fkey(full_name)
          `)
          .eq("student_id", studentId)
          .order("lesson_date", { ascending: false });

        if (error) throw error;

        // Enhance with instructor names and calculate stats
        const enhancedLessons = data.map(lesson => ({
          ...lesson,
          instructor_name: lesson.profiles?.full_name || "Unknown Instructor"
        }));

        // Calculate statistics
        const attended = enhancedLessons.filter(l => l.status === "attended").length;
        const missed = enhancedLessons.filter(l => l.status === "missed").length;
        const pending = enhancedLessons.filter(l => l.status === "pending").length;

        setStats({
          attended,
          missed,
          pending,
          total: enhancedLessons.length
        });

        setLessons(enhancedLessons);
      } catch (error) {
        console.error("Error fetching student lessons:", error);
      } finally {
        setLoading(false);
      }
    };

    if (studentId) {
      fetchLessons();
    }
  }, [studentId]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "attended":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">
            <Check className="h-3 w-3 mr-1" />
            Attended
          </Badge>
        );
      case "missed":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">
            <X className="h-3 w-3 mr-1" />
            Missed
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">
            <Clock className="h-3 w-3 mr-1" />
            Pending
          </Badge>
        );
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center p-4">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (lessons.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Lesson History</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-4">No lessons booked yet.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Lesson History</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-4 gap-2 mb-4">
          <div className="bg-slate-50 p-2 rounded text-center">
            <p className="text-lg font-semibold">{stats.total}</p>
            <p className="text-xs text-muted-foreground">Total</p>
          </div>
          <div className="bg-green-50 p-2 rounded text-center">
            <p className="text-lg font-semibold text-green-700">{stats.attended}</p>
            <p className="text-xs text-muted-foreground">Attended</p>
          </div>
          <div className="bg-yellow-50 p-2 rounded text-center">
            <p className="text-lg font-semibold text-yellow-700">{stats.pending}</p>
            <p className="text-xs text-muted-foreground">Pending</p>
          </div>
          <div className="bg-red-50 p-2 rounded text-center">
            <p className="text-lg font-semibold text-red-700">{stats.missed}</p>
            <p className="text-xs text-muted-foreground">Missed</p>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Instructor</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {lessons.map((lesson) => (
                <TableRow key={lesson.id}>
                  <TableCell>{format(new Date(lesson.lesson_date), 'PPP p')}</TableCell>
                  <TableCell className="capitalize">{lesson.lesson_type}</TableCell>
                  <TableCell>{lesson.instructor_name}</TableCell>
                  <TableCell>{getStatusBadge(lesson.status)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};
